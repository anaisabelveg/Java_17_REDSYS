package es.redsys;

import es.redsys.business.ItfzCalculadora;

public class AppMain {

	public static void main(String[] args) {
		
		
		ItfzCalculadora calcu = new ItfzCalculadora() {
			
			@Override
			public double operacion(double n1, double n2) {
				return n1 + n2;
			}
		};
		System.out.println(calcu.operacion(7, 5));
		
		// lambda:  parametros -> cuerpo de la funcion
		ItfzCalculadora suma = (double n1, double n2) -> n1 + n2;
		System.out.println(suma.operacion(7, 5));
		
		// Es obligatorio los parentesis si hay mas de un argumento
		// El tipo de los argumentos es optativo
		ItfzCalculadora resta = (n1, n2) -> n1 - n2;
		System.out.println(resta.operacion(7, 5));
		
		// Los nombres de los argumentos no tienen que ser los mismos
		ItfzCalculadora multiplicacion = (pepito, juanito) -> pepito * juanito;
		System.out.println(multiplicacion.operacion(7, 5));
		
		// Si el cuerpo de la funcion tiene varias lineas de codigo neceitamos {}
		// Y si hay llaves necesitamos return explicito
		ItfzCalculadora division = (n1, n2) -> {	
			return n1 / n2;
		};
		System.out.println(division.operacion(9, 4));

	}

}
