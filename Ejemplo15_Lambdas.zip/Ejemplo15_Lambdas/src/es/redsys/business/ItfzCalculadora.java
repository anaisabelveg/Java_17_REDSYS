package es.redsys.business;

// Una interface funcional tiene un solo metodo abstracto
@FunctionalInterface
public interface ItfzCalculadora {

	double operacion(double n1, double n2);
	
}
