/**
 * 
 */
/**
 * 
 */
module Ejemplo15_Lambdas {
}