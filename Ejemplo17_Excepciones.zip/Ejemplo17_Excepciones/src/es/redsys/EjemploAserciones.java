package es.redsys;

public class EjemploAserciones {

	public static void main(String[] args) {
		
		int numero = -8;
		
		// Si esta comprobacion la hago con un condicional (if-else)
		// ese codigo se queda ya siempre y se ejecuta
		// La aserciones se activan o no y por defecto simpre estan desactivadas
		// java -ea EjemploAserciones
		
		// Afirmo que numero > 0
		//      si es cierto no hace nada
		//      si es false lanza AssertionError
		assert (numero > 0) : "Error, el numero deberia ser positivo";

	}

}
