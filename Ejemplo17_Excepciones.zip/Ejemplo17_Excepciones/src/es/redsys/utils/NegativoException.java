package es.redsys.utils;

/*
 * Las excepciones en Java pueden ser de 2 tipos:
 * 		checked: me obliga a manejar la excepcion (Exception)
 * 		unchecked: no me obliga a manejar la excepcion (RuntimeException)
 * */
public class NegativoException extends Exception{

	public NegativoException(String message) {
		super(message);
	}
	

}
