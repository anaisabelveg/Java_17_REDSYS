package es.redsys.models;

import java.util.Objects;

public class Empleado extends Persona {

	private int numEmpleado;
	private double sueldo;

	public Empleado() {
		// De forma implicita llama a super()
	}

	public Empleado(String nombre, int edad, int numEmpleado, double sueldo) {
		super(nombre, edad); // Invocamos al constructor de la superclase
		this.numEmpleado = numEmpleado;
		this.sueldo = sueldo;
	}

	public int getNumEmpleado() {
		return numEmpleado;
	}

	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(numEmpleado, sueldo);
		return result * super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return super.equals(obj) && numEmpleado == other.numEmpleado
				&& Double.doubleToLongBits(sueldo) == Double.doubleToLongBits(other.sueldo);
	}

	@Override
	public String toString() {
		// el puntero super. apunta a la instancia de la superclase
		return super.toString() + " numEmpleado=" + numEmpleado + ", sueldo=" + sueldo;
	}

}
