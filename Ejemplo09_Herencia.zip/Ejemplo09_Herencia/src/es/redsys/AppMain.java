package es.redsys;

import es.redsys.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Empleado empleado = new Empleado("Juan", 32, 1, 47_000);
		
		// Internamente llama al metodo toString()
		//System.out.println(empleado.toString());
		System.out.println(empleado);
		
		// Con los tipos primitivos, el valor se guarda en la variable
		int num1 = 6;
		int num2 = 6;
		System.out.println("Son iguales los numeros? " + (num1 == num2));  // true  6 == 6
		
		// Cuando una variable es de tipo clase, lo que guarda es la referencia del objeto
		Empleado empleado1 = new Empleado("Juan", 32, 1, 47_000);  // #AAA
		Empleado empleado2 = new Empleado("Juan", 32, 1, 47_000);  // #BBB
		// El operador == compara el contenido de las variables
		System.out.println("Son iguales los empleados? " + (empleado1 == empleado2)); // false   #AAA == #BBB
		// El metodo equals compara el contenido de los objetos
		System.out.println("Son iguales los empleados? " + (empleado1.equals(empleado2)));  // true
		
		// Los Strings para optimizar memoria se guardan en el pool
		String nombre1 = "Pedro";   // Si es el primero se crea en el pool
		String nombre2 = "Pedro";   // Cuando utilizo la misma cadena, no la crea, me devuelve la referencia del pool
		// String son objetos pero al crearlos con asignacion 
		System.out.println("Son iguales los nombres? " + (nombre1 == nombre2)); // true  "Pedro" == "Pedro"
		
		
		// La diferencia es que estoy creando objetos y cada objeto tiene su referencia
		// En este caso no se reutilizan las cadenas del pool
		String nom1 = new String("Pedro");  // #12
		String nom2 = new String("Pedro");  // #89
		System.out.println("Son iguales los nombres? " + (nom1 == nom2));  // false   #12 == #89
		System.out.println("Son iguales los nombres? " + (nom1.equals(nom2)) );  // true
		
		
		/*
		 * CONCLUSION:
		 * 			==  solo para comparar variables de tipo primitivos; se compara el contenido de la variable
		 *  		equals()  para comparar objetos;  comparar las propiedades de cada objeto
		 * */
	}

}
