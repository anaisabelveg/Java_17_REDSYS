package es.redsys.models;

public class Empleado {

	public int numEmpleado;
	public String nombre;
	public double sueldo;
	// composicion
	public Direccion direccion;

	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public Empleado(int numEmpleado, String nombre, double sueldo, Direccion direccion) {
		super();
		this.numEmpleado = numEmpleado;
		this.nombre = nombre;
		this.sueldo = sueldo;
		this.direccion = direccion;
	}

	// Metodos, funciones, acciones
	public void mostrarDetalle() {
		System.out.println("Numero: " + numEmpleado + " Nombre: " + nombre + " Sueldo: " + sueldo +
				" Direccion: " + direccion.mostrar());
	}

	public void cambiarSueldo(double nuevo) {
		sueldo = nuevo;
	}

	public String verNombre() {
		return nombre;
	}

}
