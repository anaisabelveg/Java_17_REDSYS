package es.redsys;

import es.redsys.models.Direccion;
import es.redsys.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Empleado empleado = new Empleado();   
		empleado.numEmpleado = 1;
		empleado.nombre = "Juan";
		empleado.sueldo = 52_000;
		empleado.direccion = new Direccion("Mayor", 5, "Madrid");
		
		empleado.mostrarDetalle();
		System.out.println(empleado.verNombre());
		
		empleado.cambiarSueldo(57_000);
		empleado.mostrarDetalle();
		
		// Usar el constructor completo
		// ctrl + space
		Empleado empleado2 = new Empleado(2, "Maria", 59_000, new Direccion("Diagonal", 127, "Barcelona"));    
		empleado2.mostrarDetalle();
		empleado2.numEmpleado = 3;
		empleado2.nombre = "Pepito";
		empleado2.sueldo = 60_000;
		
	}

}
