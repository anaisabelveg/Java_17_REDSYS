package es.redsys;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class AppMain {

	public static void main(String[] args) {
		
		// Definiendo los locales (que idiomas vamos a utilizar)
		Locale espanyol = new Locale("es", "ES");
		Locale colombia = new Locale("es", "CL");
		Locale ingles = new Locale("en");
		
		// Cargar los archivos de mensajes para cada idioma
		ResourceBundle esESBundle = ResourceBundle.getBundle("mensajes", espanyol);
		ResourceBundle esCLBundle = ResourceBundle.getBundle("mensajes", colombia);
		ResourceBundle enBundle = ResourceBundle.getBundle("mensajes", ingles);
		
		// Mostrar el saludo en ambos idiomas
		System.out.println(esESBundle.getString("saludo"));
		System.out.println(esCLBundle.getString("saludo"));
		System.out.println(enBundle.getString("saludo"));
		
		// Felicitar a alquien
		System.out.println(MessageFormat.format(esESBundle.getString("felicitar"), "Pepito") );
		System.out.println(MessageFormat.format(esCLBundle.getString("felicitar"), "Pepito") );
		System.out.println(MessageFormat.format(enBundle.getString("felicitar"), "Pepito") );

	}

}
