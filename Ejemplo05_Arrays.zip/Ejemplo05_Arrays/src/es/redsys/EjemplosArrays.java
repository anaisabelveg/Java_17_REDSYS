package es.redsys;

import java.util.Arrays;

public class EjemplosArrays {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];  // null
		String [] nombres; // null
		char[] letras;  // null
		
		// Cuidado con las declaraciones multiples
		int a[], b, c, d;  // a es array y el resto variables enteras
		int [] e, f, g, h; // todos son arrays
		
		
		// Crear el array
		numeros = new int[4];   // Es obligatorio darle un tamaño
		
		// Asignar valores en el array
		numeros[0] = 6;
		numeros[1] = 3;
		numeros[2] = 9;
		numeros[3] = 1;
		//numeros[4] = 6;   si  no existe ese indice ArrayIndexOfBoundsException
		
		// Forma comoda
		int numeros2[] = {6,3,9,1};
		int numeros3[] = new int[]{6,3,9,1};
		
		// Recorrer un array: for tradicional y for-each
		for (int i=0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		for (int num : numeros) {
			System.out.println(num);
		}
		
		// En Java, los arrays no son redimensionales
		// Si se queda pequeño, creamos uno mas grande y hacermos volcado de datos
		int[] grande = new int[10];
		System.arraycopy(numeros, 0, grande, 0, numeros.length);
		
		System.out.println(grande);
		System.out.println(Arrays.toString(grande));
	}

}
