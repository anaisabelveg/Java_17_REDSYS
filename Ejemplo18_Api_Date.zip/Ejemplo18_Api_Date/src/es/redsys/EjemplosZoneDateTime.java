package es.redsys;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class EjemplosZoneDateTime {

	public static void main(String[] args) {
		
		// Mostrar las zonas horarias
		System.out.println(ZoneId.getAvailableZoneIds());
		
		// Crear la zona horaria de Nueva York
		ZoneId USEast = ZoneId.of("America/New_York");
		
		// Ahora en Madrid, que hora es?
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);
		
		// Cual es la hora en Nueva York
		System.out.println(ZonedDateTime.now(USEast));
		
		// Fecha y hora del vuelo en España
		LocalDateTime vuelo = LocalDateTime.of(2024, Month.DECEMBER, 31, 21, 30);
		System.out.println(vuelo);
		
		// Convertir esa fecha y hora en horario Nueva York
		ZonedDateTime newYork = ZonedDateTime.of(vuelo, USEast);
		System.out.println(newYork);
		System.out.println("Diferencia horaria: " + newYork.getOffset());
		System.out.println(vuelo.minusHours(5));

	}

}
