package es.redsys;

import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;

public class Practica {

	public static void main(String[] args) {
		
		// Lincoln nace el 12 de febrero de 1809
		// Fallece el 15 de abril de 1855
		LocalDate nacimiento = LocalDate.of(1809, Month.FEBRUARY, 12);
		LocalDate fallecimiento = LocalDate.of(1855, Month.APRIL, 15);
		
		// Cuantos años tenia cuando murio?
		System.out.println(nacimiento.until(fallecimiento, ChronoUnit.YEARS) + " años");
		
		// Cuantos dias vivio?
		System.out.println(nacimiento.until(fallecimiento, ChronoUnit.DAYS) + " dias");
		
		// Si el año de sus nacimiento era bisiesto?
		System.out.println(nacimiento.isLeapYear());
		
		// Cuantas decadas han transcurrido desde su fallecimiento?
		LocalDate hoy = LocalDate.now();
		System.out.println(fallecimiento.until(hoy, ChronoUnit.DECADES) + " decadas");
		
		// Que dia de la semana nacio?
		System.out.println(nacimiento.getDayOfWeek());
		
		// Que dia de la semana fue su 30 cumpleaños?
		System.out.println(nacimiento.plusYears(30).getDayOfWeek());

	}

}
