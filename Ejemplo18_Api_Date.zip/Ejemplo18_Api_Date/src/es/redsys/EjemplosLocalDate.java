package es.redsys;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class EjemplosLocalDate {

	public static void main(String[] args) {
		
		// Fecha de hoy
		LocalDate hoy = LocalDate.now();
		System.out.println(hoy); 
		
		// Fecha de mi cumpleaños
		LocalDate miCumple = LocalDate.of(2024, Month.JULY, 1);
		
		// Ya ha sido tu cumpleaños?
		System.out.println(hoy.isAfter(miCumple));
		
		// En que dia de la semana cae mi cumple
		System.out.println(miCumple.getDayOfWeek());
		DayOfWeek dia = miCumple.getDayOfWeek();
		
		// Es bisiesto?
		System.out.println(miCumple.isLeapYear());
		//DayOfWeek.SATURDAY;
		
		// Dime cuando es el siguiente sabado
		System.out.println(hoy.with(TemporalAdjusters.next(DayOfWeek.SATURDAY)));
		
		// Sumar un año
		System.out.println(hoy.plusYears(1));
		
		// Restar 5 dias
		System.out.println(hoy.minusDays(5));

	}

}
