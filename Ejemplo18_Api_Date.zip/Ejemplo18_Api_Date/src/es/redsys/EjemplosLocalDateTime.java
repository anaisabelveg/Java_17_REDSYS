package es.redsys;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class EjemplosLocalDateTime {

	public static void main(String[] args) {
		
		// El vuelo es el 31 de Diciembre de 2024 a las 21:30
		LocalDateTime vuelo = LocalDateTime.of(2024, Month.DECEMBER, 31, 21, 30);
		
		// Otra forma
		LocalDate fecha = LocalDate.of(2024, Month.DECEMBER, 31);
		LocalTime hora = LocalTime.of(21, 30);
		LocalDateTime vuelo2 = LocalDateTime.of(fecha, hora);
		
		// Aplazar el vuelo 1 semana
		System.out.println(vuelo.plusWeeks(1));
		
		// Adelantar el vuelo 10 dias
		System.out.println(vuelo2.minusDays(10));

	}

}
