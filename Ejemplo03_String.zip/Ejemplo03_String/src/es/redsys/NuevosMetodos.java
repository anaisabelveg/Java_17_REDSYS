package es.redsys;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NuevosMetodos {

	public static void main(String[] args) {
		
		// isBlank
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		
		// repeat()
		System.out.println("*".repeat(20));
		System.out.println("ja".repeat(5));
	
		
		// strip()
		String nombre = "     Juan     ";
		System.out.println(nombre + ".");
		
		// Quitar espacios derecha e izquierda
		System.out.println(nombre.strip() + ".");
		
		// Solo quitar espacios por la izquierda
		System.out.println(nombre.stripLeading() + ".");
		
		// Solo quitar espacios por la derecha
		System.out.println(nombre.stripTrailing() + ".");
		
		// lines()
		String texto = "Hola\nque\ntal?\nmañana\nes\nmartes";
		System.out.println(texto);
		Stream<String> flujo = texto.lines();
		List<String> lista = flujo.collect(Collectors.toList()); 
		System.out.println(lista);

	}

}
