package es.redsys;

public class EjercicioMetodosString {

	public static void main(String[] args) {
		
		String cadena = "Bienvenido al curso de Java";
		
		// Mostrar la cadena toda en mayusculas
		System.out.println(cadena.toUpperCase());
		
		// Mostrar la cadena toda en minusculas
		System.out.println(cadena.toLowerCase());
		
		// Mostrar solo la palabra Bienvenido
		int posEspacio = cadena.indexOf(" ");
		System.out.println(cadena.substring(0, posEspacio));
		System.out.println(cadena.substring(0, cadena.indexOf(" ")));
		
		// Mostrar solo la palabra Java
		System.out.println(cadena.substring(cadena.lastIndexOf(" ") + 1));
		
		// Mostrar solo la palabra curso
		int posC = cadena.indexOf("c");
		posEspacio = cadena.indexOf(" ", posC);
		System.out.println(cadena.substring(posC, posEspacio));
		
		// Mostrar la posicion de la letra c
		System.out.println(cadena.indexOf("c"));
		
		// Mostrar la longitud de la cadena
		System.out.println(cadena.length());
		
		// Cambiar las e por E
		System.out.println(cadena.replace('e', 'E'));
		
		// Concatenar la cadena original con " con fecha 9 de Diciembre"
		System.out.println(cadena.concat(" con fecha 9 de Diciembre"));
		
		// Consultar la clase String en el API de Java 17
		// https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/String.html

	}

}
