package es.redsys;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.zip.GZIPOutputStream;

public class ComprimirFichero {

	public static void main(String[] args) {
		
		try (FileOutputStream fos = new FileOutputStream("comprimido.zip");
			 GZIPOutputStream gStream = new GZIPOutputStream(fos);
			 BufferedWriter buffer = new BufferedWriter(new OutputStreamWriter(gStream)) 	){
			
			buffer.write("Esto es una prueba para ver la compresion de ficheros");
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
