package es.redsys;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirFichero {

	public static void main(String[] args) {
		
		// Los recursos que se abren dentro de los parentesis del bloque try
		// y ademas con AutoCloseables, se cierran solor
		// No es necesario llamar al metodo close
		try(FileWriter fichero = new FileWriter("datos.txt");
			BufferedWriter buWriter = new BufferedWriter(fichero);){
			
			// Escribir contenido en el fichero
			buWriter.write("Hola");
			buWriter.write("\n");
			buWriter.write("Como estas?\n");
			buWriter.write("Mañana es viernes");
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
