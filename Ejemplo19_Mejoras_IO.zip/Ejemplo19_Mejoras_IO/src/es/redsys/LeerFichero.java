package es.redsys;

import java.io.BufferedReader;
import java.io.FileReader;

public class LeerFichero {

	public static void main(String[] args) {
		
		try (FileReader fichero = new FileReader("datos.txt");
				BufferedReader bReader = new BufferedReader(fichero)){
			
			// Leer el contenido del fichero
			bReader.lines()
				.map(linea -> linea.toUpperCase())
				.forEach(System.out::println);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
