package es.redsys;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import es.redsys.models.Empleado;

public class DeserializarObjetos {

	public static void main(String[] args) {
		
		
		try (FileInputStream fichero = new FileInputStream("empleado.ser");
				ObjectInputStream inputStream = new ObjectInputStream(fichero)){
			
			// Serializacion
			Empleado empleado =  (Empleado) inputStream.readObject();
			empleado.mostrarDetalle();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
