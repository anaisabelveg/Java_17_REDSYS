package es.redsys;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import es.redsys.models.Empleado;

public class SerializarObjetos {

	public static void main(String[] args) {
		
		// Para poder serializar objetos, la clase tiene que ser serializable
		Empleado empleado = new Empleado(1, "Juan", 59_000);
		
		try (FileOutputStream fichero = new FileOutputStream("empleado.ser");
				ObjectOutputStream outputStream = new ObjectOutputStream(fichero)){
			
			// Serializacion
			outputStream.writeObject(empleado);
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
