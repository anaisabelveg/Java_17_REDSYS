package es.redsys;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

public class DescomprimirFichero {

	public static void main(String[] args) {
		
		try (FileInputStream fis = new FileInputStream("comprimido.zip");
			 GZIPInputStream gStream = new GZIPInputStream(fis);
			 BufferedReader buffer = new BufferedReader(new InputStreamReader(gStream)) 	){
			
			buffer.lines()
				.forEach(System.out::println);
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
