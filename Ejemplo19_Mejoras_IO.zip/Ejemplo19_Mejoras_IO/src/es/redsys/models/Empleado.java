package es.redsys.models;

import java.io.Serializable;

public class Empleado implements Serializable{
	
	// atributos, propiedades, campos, caracteristicas
	// Variables globales
	public int numEmpleado;
	public String nombre;
	public double sueldo;

	
	// Constructor por defecto
	// El compilador en el momento de la compilacion comprueba si existe algun constructor
	// si no existe ninguno, añade el constructor por defecto
	// Buena practica, mantener siempre el constructor por defecto
	public Empleado() {
		// TODO Auto-generated constructor stub
	}
	
	// Constructor completo
	public Empleado(int numEmpleado, String nombre, double sueldo) {
		super();
		this.numEmpleado = numEmpleado;   // this apunta a la propia instancia
		this.nombre = nombre;
		this.sueldo = sueldo;
	}

	// Metodos, funciones, acciones
	public void mostrarDetalle() {
		System.out.println("Numero: " + numEmpleado + " Nombre: " + nombre +
				" Sueldo: " + sueldo);
	}
	
	public void cambiarSueldo(double nuevo) {
		sueldo = nuevo;
	}
	
	public String verNombre() {
		return nombre;
	}

}
