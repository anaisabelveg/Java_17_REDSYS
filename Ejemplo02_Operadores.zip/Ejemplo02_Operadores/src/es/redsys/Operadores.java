package es.redsys;

public class Operadores {

	public static void main(String[] args) {
	
		double num1 = 8.0;
		int num2 = 3;
		
		// Operadores aritmeticos
		System.out.println("Suma: " + (num1 + num2));
		System.out.println("Resta: " + (num1 - num2));
		System.out.println("Multiplicacion: " + (num1 * num2));
		System.out.println("Division: " + (num1 / num2));
		System.out.println("Resto: " + (num1 % num2));
		
		// Incrementos y decrementos
		num2++;   // num2 = num2 + 1    // num2 += 1
		num2--;   // num2 = num2 - 1    // num2 -= 1
		
		int resultado = num2++;   // post-incremento   1º asigna, 2º incrementa
		resultado = ++num2;       // pre-incremento    1º incrementa, 2º asigna
		
		
		// Operadores de comparacion
		boolean mayor = num1 > num2;
		System.out.println( (num1 == 8) && (num2 < 10) );
		
		
		// Operadores de asignacion
		num1 += 5;  // num1 = num1 + 5;
		num1 -= 5;  // num1 = num1 - 5;
		num1 *= 5;  // num1 = num1 * 5;
		num1 /= 5;  // num1 = num1 / 5;
		num1 %= 5;  // num1 = num1 % 5;
	}

}
