package es.redsys;

public class Break_Continue {

	public static void main(String[] args) {
		
		// mostrar los numeros primos del 1 al 100
		
		// ponemos una etiqueta al bucle de los numeros
		bucle_Numeros:
		for (int numero = 1; numero <= 100; numero++) {
			System.out.println("******************* Probando numero " + numero);
			
			boolean esPrimo = true;
			
			// Empezamos a buscar divisores de ese numero
			for(int divisor = 2; divisor < numero; divisor++) {
				System.out.println("Probando divisor " + divisor + "*******************");
				if (numero % divisor == 0) {
					esPrimo = false;
					//break;  // Da por finalizado el bucle de los divisores
					continue bucle_Numeros;  // Da por finalizada esta iteraccion y pasa al siguiente numero
				}
			}
			
			if (esPrimo) {
				System.out.println(numero);
			}
		}

	}

}
