package es.redsys;

import java.util.Scanner;

public class While {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce password: ");
		String pw = sc.nextLine();
		
		//while (! null.equals("curso")) {   --->  NullPointerException
		while (!"curso".equals(pw)) {  // false
			System.out.println("No has acertado, vuelve a intentarlo");
			System.out.println("Introduce password: ");
			pw = sc.next();
		}
		
		System.out.println("Por fin acertaste");
		
		sc.close();
	}

}
