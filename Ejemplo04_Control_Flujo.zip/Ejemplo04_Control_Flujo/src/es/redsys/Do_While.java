package es.redsys;

import java.util.Scanner;

public class Do_While {

	public static void main(String[] args) {
		
		// Metodo estatico   ->  Clase.metodo()
		int aleatorio = (int)(Math.random() * 10 + 1);
		int numero = 0;
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Introduce numero del 1 al 10: ");
			numero = sc.nextInt();
			
			if (numero > aleatorio) {
				System.out.println("Te has pasado, prueba con otro numero menor");
			} else if (numero < aleatorio) {
				System.out.println("Te has quedado corto, prueba con otro numero mayor");
			} else {
				System.out.println("Enhorabuena, acertaste");
			}
			
		} while (aleatorio != numero);
		
		// Cerrar un recurso
		sc.close();	
		
	}

}
