package es.redsys;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import es.redsys.models.Provincia;

public class OperacionesFinales {

	public static void main(String[] args) {
		
		List<Provincia> lista = Arrays.asList(
				new Provincia("Madrid", 87, 67_886_543, 28, "Español", "Madrid", 90.67),
				new Provincia("Valencia", 45, 7876876, 46 , "Valenciano", "Valencia", 91.3),
				new Provincia("Coruña", 39, 54545, 9, "Gallego", "Coruña", 78.23),
				new Provincia("Toledo", 26, 3677556, 38, "Español", "Toledo", 35.17),
				new Provincia("Ourense", 29, 788866, 27, "Gallego", "Ourense", 28.68),
				new Provincia("Cuenca", 15, 986442, 16, "Español", "Cuenca", 34.12),
				new Provincia("Barcelona", 74, 556779, 8, "Catalan", "Barcelona", 97.25),
				new Provincia("Zamora", 28, 987656, 42, "Español", "Zamora", 56.34),
				new Provincia("Guipuzcoa", 35, 432223, 20, "Euskera", "San Sebastian", 48.23),
				new Provincia("Vizcaya", 48, 567654, 6, "Euskera", "Bilbao", 54.89)	
		);
		
		// max
		// Provincia con mayor numero de habitantes
		Provincia maxHabitantes = lista.stream()
			.max(Comparator.comparing(Provincia::getPoblacion))
			.orElse(new Provincia());  // Saca la provincia del objeto Optional o una alternativa
		System.out.println(maxHabitantes);
		
		
		// min
		// Provincia con menor densidad de poblacion
		Provincia menorDensidad = lista.stream()
			.min(Comparator.comparing(Provincia::getDensidadPoblacion))
			.get();  // Saca la provincia del objeto Optional
		System.out.println(menorDensidad);
		
		
		// average
		// Media de localidades por provincia
		double mediaLocalidades = lista.stream()
			.mapToInt(prov -> prov.getNumLocalidades())
			.average()
			.getAsDouble();
		System.out.println(mediaLocalidades);
		
		
		// count
		// Contar cuantas provincias tienen una densidad de poblacion inferior a 50
		long numProvinciasPocaDensidad = lista.stream()
			.filter(prov -> prov.getDensidadPoblacion() < 50)
			.count();
		System.out.println(numProvinciasPocaDensidad);
		

		// sum
		// Total de habitantes (sumar todos los habitantes por provincia)
		int totalPoblacion = lista.stream()
			.mapToInt(prov -> prov.getPoblacion())
			.sum();
		System.out.println(totalPoblacion);
		
		
		// collect
		// Crear una lista con las provincias con dialecto Español
		lista.stream()
			.filter(prov -> prov.getDialecto().equals("Español"))
			.collect(Collectors.toList())
			.forEach(System.out::println);
		
		// Crear un mapa donde: 
		// la key sea el dialecto y 
		// el value las lista de las provincias con ese dialecto
		Map<String, List<Provincia>> mapaDialectos = lista.stream()
				.collect(Collectors.groupingBy(Provincia::getDialecto));
		mapaDialectos.forEach((k,v) -> {
			System.out.println("Dialecto: " + k);
			v.forEach(System.out::println);
		});
		
		// Generar una cadena de texto con los distintos dialectos ordenados, separados por -
		String dialectos = lista.stream()
			.map(p -> p.getDialecto())
			.distinct()
			.sorted()
			.collect(Collectors.joining(" - "));
		System.out.println(dialectos);
	}

}











