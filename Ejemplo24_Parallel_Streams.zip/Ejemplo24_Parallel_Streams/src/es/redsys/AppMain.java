package es.redsys;

import java.util.Arrays;
import java.util.List;

public class AppMain {

	/* 
	 * Los Parallel Streams perocesar colecciones de forma paralela sacando
	 * partido a todos los procesadores.
	 * 
	 * Permite dividir la tarea utilizando streams de forma automatica
	 * Son utiles con operaciones donde no depende el orden de ejecucion
	 * Agiliza mucho el tiempo
	 * 
	 * */
	
	public static void main(String[] args) {
		
		// Ejemplo1: sumar numeros utilizando un stream secuencial
		List<Integer> numeros = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		long tiempoInicio = System.currentTimeMillis();
		
		int suma = numeros.stream()
				.mapToInt(n -> {
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}  // parar durante 10 milisegundos
					return n;
				})
				.sum();

		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Suma: " + suma);
		System.out.println("Tiempo suma secuencial: " + (tiempoFinal - tiempoInicio) + " mseg.");
		
		
		// Ejemplo2: sumar numeros utilizando un parallel stream
		tiempoInicio = System.currentTimeMillis();
		
		int sumaParallel = numeros.parallelStream()
				.mapToInt(n -> {
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}  // parar durante 10 milisegundos
					return n;
				})
				.sum();

		tiempoFinal = System.currentTimeMillis();
		System.out.println("Suma: " + sumaParallel);
		System.out.println("Tiempo suma parallel: " + (tiempoFinal - tiempoInicio) + " mseg.");
	}

}
