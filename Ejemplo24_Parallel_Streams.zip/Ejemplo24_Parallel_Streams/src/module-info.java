/**
 * 
 */
/**
 * 
 */
module Ejemplo24_Parallel_Streams {
}