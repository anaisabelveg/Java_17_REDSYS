/**
 * 
 */
/**
 * 
 */
module Ejemplo11_Clases_Abstractas {
}