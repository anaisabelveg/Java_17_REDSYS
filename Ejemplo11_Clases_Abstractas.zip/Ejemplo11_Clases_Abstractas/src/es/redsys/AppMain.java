package es.redsys;

import es.redsys.models.Figura;
import es.redsys.models.Triangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// Una clase abstracta se puede utilizar como tipo pero no instanciar
		//Figura f = new Figura();
		
		// Si me permite instanciar figura si en ese momento implemento el metodo abstracto
		// Clase anonima
		Figura f = new Figura(10, 20) {
			
			@Override
			public double calcularArea() {
				// TODO Auto-generated method stub
				return 0;
			}
		};
		
		
		Triangulo t = new Triangulo(5, 10, 45, 30);
		System.out.println(t.calcularArea());

	}

}
