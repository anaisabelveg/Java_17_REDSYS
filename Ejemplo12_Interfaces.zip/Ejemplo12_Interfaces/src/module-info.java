/**
 * 
 */
/**
 * 
 */
module Ejemplo12_Interfaces {
}