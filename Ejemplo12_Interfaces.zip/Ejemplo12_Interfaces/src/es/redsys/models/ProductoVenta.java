package es.redsys.models;

public interface ProductoVenta {
	
	// No existen las variables, todo son constantes
	//double precio;
	
	
	// Declarar metodos abstractos
	// Por defecto, todos los metodos seran publicos y abstractos
	public void setPrecio(double precio);
	public abstract void setCodigo(String codigo);
	
	abstract double getPrecio();
	String getCodigo();

}
