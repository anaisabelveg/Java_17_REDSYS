package es.redsys.models;

// Una clase encapsulada, tiene todas sus propiedades declaradas como privadas
// y solo se accede a ellas a través de los métodos get y set publicos
public class FechaEncapsulada {

	// los recursos privados solo son accesibles dentro de la clase
	private int dia;
	private int mes;
	private int anyo;

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		if (dia > 0 && dia <= 31)
			this.dia = dia;
		else
			System.out.println("Dia no valido");
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12)
			this.mes = mes;
		else
			System.out.println("Mes no valido");
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo == 2024 || anyo == 2025)
			this.anyo = anyo;
		else
			System.out.println("Año no valido");
	}

	public void mostrar() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
