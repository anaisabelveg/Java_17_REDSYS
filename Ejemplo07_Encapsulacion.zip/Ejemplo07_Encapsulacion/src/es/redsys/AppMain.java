package es.redsys;

import es.redsys.models.Fecha;
import es.redsys.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 10;
		fecha.mes = 12;
		fecha.anyo = 2024;
		
		fecha.mostrar();
		
		Fecha fechaErronea = new Fecha();
		fechaErronea.dia = 10089;
		fechaErronea.mes = -156;
		fechaErronea.anyo = 76;
		
		fechaErronea.mostrar();
		
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(8);
		fechaEncapsulada.setMes(9);
		fechaEncapsulada.setAnyo(2025);
		fechaEncapsulada.mostrar();

	}

}
