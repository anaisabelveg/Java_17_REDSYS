package es.redsys;

import es.redsys.models.Empleado;
import es.redsys.models.Jefe;
import es.redsys.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Tengo visibilidad de Jefe
		Jefe jefe = new Jefe("Juan", 32, 1, 47_000, 100_000);
		
		System.out.println(jefe);
		// Puedo acceder a cualquier recurso de jefe
		System.out.println(jefe.getSueldo());
		
		
		// Cambiar la visibilidad del objeto jefe a Persona
		// IMPORTANTE!!! el objeto no cambia, solo la forma de verlo
		// La visibilidad me lo da el tipo de la variable
		Persona p = jefe;
		
		// Solo veo los recursos de Persona
		System.out.println(p.getNombre());
		
		// Si yo muestro el objeto, llama al toString() y ejecuta el del objeto
		System.out.println(p);
		
		// Cambio la visibilidad de p a Empleado
		Empleado e = (Empleado) p;   // casting
		e.setSueldo(50_000);
		
		
		// Para que sirve el polimorfismo? 
		procesar(p);
		procesar(jefe);
		procesar(new Empleado());
		
	}
	
	
	public static void procesar(Object obj) {
		
	}
	

}
