package es.redsys;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class AppMain {

	public static void main(String[] args) {
		
		// Ejemplo 5 hilos para procesar 10 tareas
		
		// Creando un pool para los 5 hilos
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		
		// Crear las 10 tareas y enviarlas al pool
		for (int i=1; i<= 10; i++) {
			final int idTarea = i;
			executorService.execute( () -> {
				System.out.println("Tarea " + idTarea + " iniciada por " + Thread.currentThread().getName());
				
				// Codigo a ejecutar muy pesado y tarda tiempo
				try {
					Thread.sleep(3_000);  // 3000 milisegundos = 3 segundos
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
				
				System.out.println("Tarea " + idTarea + " completado por " + Thread.currentThread().getName());
			});
		
		}
		
		
		// Apagar el pool
		executorService.shutdown();
		
		// Esperar a que terminen todas las tareas o esperar 10 segundos
		try {
			if (!executorService.awaitTermination(10, TimeUnit.SECONDS)) {
				executorService.shutdownNow();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Todas las tareas completadas");

	}

}
