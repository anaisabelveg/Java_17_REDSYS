/**
 * 
 */
/**
 * 
 */
module Ejemplo13_Nuevos_Metodos_Interfaces {
}