package es.redsys.business;

public interface ItfzMetodos {
	
	// Novedades en Java 8:
	//    - Metodos estaticos
	//	  - Metodos default
	
	public static void estatico() {
		System.out.println("Método estatico");
		// Desde un metodo estatino no puedo acceder a contenido no estatico
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
	}
	
	
	// En Java 9, metodos privados que se invocan desde metodos deafult
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) +
				" Minusculas: " + minusculas(texto);
	}

}
