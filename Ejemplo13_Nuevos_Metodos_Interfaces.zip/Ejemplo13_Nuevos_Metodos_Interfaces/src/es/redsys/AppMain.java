package es.redsys;

import es.redsys.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		// Los metodos estaticos no necesitan una instancia
		ItfzMetodos.estatico();
		
		// Los metodos default si necesitan instancia
		ItfzMetodos metodos = new ItfzMetodos() {
		};
		metodos.defecto();
		System.out.println(metodos.procesarTexto("Hola, que tal?"));

	}

}
