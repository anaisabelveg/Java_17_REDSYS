package es.redsys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		Set numeros = new HashSet();
		numeros.add(1);
		numeros.add("dos");
		numeros.add(1);  // Ignora los valores repetidos
		numeros.add(Integer.valueOf(3));
		
		for (Object obj : numeros) {
			System.out.println(obj);
		}
		System.out.println("-".repeat(20));
		
		// Java 5 incluye genericos
		// Limitar el tipo de los elementos de la coleccion
		Set<Integer> numeros2 = new HashSet<Integer>();
		numeros2.add(1);
		//numeros2.add("dos");   // Error de compilacion
		numeros2.add(1);  // Ignora los valores repetidos
		numeros2.add(Integer.valueOf(3));
		
		for (Integer num : numeros2) {
			System.out.println(num);
		}
		System.out.println("-".repeat(20));
		
		// A partir de Java 7 podemos quitar el tipo generico del constructor
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add("Juan");  // Acepta valores repetidos
		
		for (String nombre : nombres) {
			System.out.println(nombre);
		}
		
		System.out.println(nombres);
		
		
		Map<String, Double> alumnos = new HashMap<String, Double>();
		alumnos.put("Juan", 6.3);
		alumnos.put("Maria", 8.9);
		alumnos.put("Pedro", 2.5);
		
		System.out.println("Nota de Pedro: " + alumnos.get("Pedro"));
		System.out.println("Valores: " + alumnos.entrySet());
		System.out.println("Alumnos: " + alumnos.keySet());
		System.out.println("Notas: " + alumnos.values());
		
		// ctrl + shift + o
		for (Entry<String, Double> item : alumnos.entrySet()) {
			if (item.getValue() == 2.5) {
				System.out.println(item.getKey());
			}		
		}
				
	}

}











