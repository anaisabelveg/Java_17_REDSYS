/**
 * 
 */
/**
 * 
 */
module Ejemplo01_TiposPrimitivos {
}