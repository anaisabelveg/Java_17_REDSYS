package es.redsys;

public class AppMain {

	// Marca el punto de entrada a la aplicacion
	public static void main(String[] args) {
		
		/*
		 * Ejemplo para mostrar los tipos primitivos 
		 */

		// Numericos enteros
		byte numByte = (byte) 8;          // 8 bits
		short numShort = 250;             // 16 bits
		int numInt = 56987;               // 32 bits  (defecto)
		long numLong = 8765544568976L;    // 64 bits sufijo L ó l
		
		// Numericos reales
		float numFloat = 3.1416F;         // 32 bits sufijo F ó f
		double numDouble = 6787.355;	  // 64 bits (defecto)
		
		// Booleanos: true y false
		boolean incidencia = true;
		
		// Caracteres: 'caracter'
		char letra = 'k';
		
		
		// String es una clase, no es un tipo primitivo
		// La clase se escribe primera letra con mayuscula.
		// Las cadenas de texto van entre comillas dobles
		String saludo = "Hola, que tal?";
		
		// syso + ctrl + space
		System.out.println(saludo);
		System.out.println("Numero entero: " + numInt);
		
		// Palabra reservada
		// String goto = 'hola';
	}

}
