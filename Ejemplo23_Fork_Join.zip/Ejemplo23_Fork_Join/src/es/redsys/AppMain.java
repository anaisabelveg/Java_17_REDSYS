package es.redsys;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.stream.LongStream;

public class AppMain {
	
	/* 
	 * Fork/Join (divide y venceras) es un framework para mejorar las ejecuciones en paralelo
	 * sacandole el maximo partido a los nucleos del microprocesador.
	 * 
	 * Divide una tarea grande en subtareas al final combina el resultado de ambas subtareas para emitir el resultado final
	 * 
	 * Clases o componentes principales:
	 * 		ForkJoinPool: El pool donde gestionamos las tareas.
	 * 		ForkJoinTask: Clase abstracta que define la tarea a ejecutar
	 * 		RecursiveAction: Subclase de ForkJoinTask para tareas sin retorno
	 * 		RecursiveTask: Subclase de ForkJoinTask para tareas con retorno
	 * 
	 * Funcionamiento:
	 * 		1.- crear la tarea a ejecutar con RecursiveAction o RecursiveTask
	 * 		2.- se envia la tarea al pool ForkJoinPool
	 * 		3.- El propio framework lo divide en subtareas ("operacion fork")
	 * 		4.- Las subtareas se ejecutan en paralelo
	 * 		5.- Los resultados se combinan ("operacion join")
	 * */

	public static void main(String[] args) {
		// Crear un array muy grande de numeros
		LongStream stLong = LongStream.rangeClosed(1, 500_000_000);
		long[] arrayNumeros =  stLong.toArray();
		
		// Crear el pool
		ForkJoinPool pool = ForkJoinPool.commonPool();
		
		// Crear la tarea
		TareaSumar tarea = new TareaSumar(arrayNumeros, 0, arrayNumeros.length);
		
		// Ejecutar la tarea y recibir el resultado de la suma
		long tiempoInicio = System.currentTimeMillis();
		long resultado = pool.invoke(tarea);
		System.out.println("Resultado: " + resultado);
		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Tiempo invertido: " + (tiempoFinal - tiempoInicio) + " mseg");

	}
	
	static class TareaSumar extends RecursiveTask<Long>{
		
		private long[] numeros;
		private int inicio;
		private int fin;
		
		public TareaSumar(long[] numeros, int inicio, int fin) {
			super();
			this.numeros = numeros;
			this.inicio = inicio;
			this.fin = fin;
		}

		@Override
		protected Long compute() {
			// Prueba a sumar todos los numeros sin dividir en tareas  153 mseg
//			long suma = 0;
//			for (int i=inicio; i < fin;i++) {
//				suma += numeros[i];
//			}
//			return suma;
			
			// Sumar por bloques de 1000
			// Si el tamaño de la subtarea (subarray) es menor de 1000 lo suma
			// Si es mayor lo divide en 2 subtareas
			// Tiempo: 257 mseg
			if (fin - inicio <= 1000) {
				long suma = 0;
				for (int i=inicio; i < fin;i++) {
					suma += numeros[i];
				}
				return suma;
			} else {
				int mitad = (inicio + fin) / 2;
				TareaSumar subarray1 = new TareaSumar(numeros, inicio, mitad);
				TareaSumar subarray2 = new TareaSumar(numeros, mitad, fin);
				
				// Fork las subtareas
				subarray1.fork();
				subarray2.fork();
				
				// Join de los resultados
				return subarray1.join() + subarray2.join();
			}
			
		}
		
	}

}
